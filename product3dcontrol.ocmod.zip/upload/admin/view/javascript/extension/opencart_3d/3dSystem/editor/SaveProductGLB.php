<?php
//CONECT TO DB
require(dirname(__DIR__, 7).'/config.php');
$servername = DB_HOSTNAME;
$username = DB_USERNAME;
$password = DB_PASSWORD;
$dbname = DB_DATABASE;
$conn = new mysqli($servername, $username, $password, $dbname);


// Check if file upload is successful
if (isset($_FILES['glbFile']) && $_FILES['glbFile']['error'] === UPLOAD_ERR_OK) {
    // Access uploaded file properties
    $tempFilePath = $_FILES['glbFile']['tmp_name'];
    $originalFileName = $_FILES['glbFile']['name'];

    $prodDir = dirname(__DIR__, 7).'/image/catalog/extension/module/product3dcontrol/products/'.$_POST['product_id'];
    if(!file_exists($prodDir)){
        mkdir($prodDir);
    }
    $uniqueName = md5(uniqid());
    // Move uploaded file to desired location
    move_uploaded_file($tempFilePath, $prodDir . '/'.$uniqueName.'.glb');
    $sql = "INSERT INTO `oc_product_models`(`product_id`, `name`) 
            VALUES ('".$_POST['product_id']."','".$uniqueName."')
            ON DUPLICATE KEY
            UPDATE 
            `name` = '".$uniqueName."'";
    $conn->query($sql);
    $sql = "UPDATE `oc_product` SET `has_model` = 1 WHERE `product_id` = ".$_POST['product_id'];
    $conn->query($sql);
    echo 'GLB file saved successfully.';
} else {
    echo 'Failed to save GLB file.';
}