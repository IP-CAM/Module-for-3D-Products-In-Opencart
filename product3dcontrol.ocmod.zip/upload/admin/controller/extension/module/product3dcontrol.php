<?php
class ControllerExtensionModuleProduct3DControl extends Controller {
	private $error = array();

	public function install() {
        // Create the custom table
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "product_models` (
            `product_id` INT(11) NOT NULL,
            `name` VARCHAR(32) NOT NULL,
            PRIMARY KEY (`product_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;");

        // Check if 'has_model' column exists in oc_product
        $query = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product` LIKE 'has_model'");
        if (!$query->num_rows) {
            // Add the 'has_model' column to oc_product
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "product` ADD COLUMN `has_model` TINYINT(1) NOT NULL DEFAULT 0");
        }
        // Insert a test product
        $this->db->query("INSERT INTO `" . DB_PREFIX . "product` SET 
            model = 'Test Model', 
            sku = 'TEST3DPRODUCT', 
            upc = '', 
            ean = '', 
            jan = '', 
            isbn = '', 
            mpn = '', 
            location = '', 
            quantity = 10, 
            stock_status_id = 7, 
            image = 'catalog/extension/module/product3dcontrol/images/image_1.jpg', 
            manufacturer_id = 0, 
            shipping = 1, 
            price = 99.99, 
            points = 0, 
            tax_class_id = 0, 
            date_available = NOW(), 
            weight = 1.00, 
            weight_class_id = 1, 
            length = 0, 
            width = 0, 
            height = 0, 
            length_class_id = 1, 
            subtract = 1, 
            minimum = 1, 
            sort_order = 1, 
            status = 1, 
            has_model = 1,
            viewed = 0, 
            date_added = NOW(), 
            date_modified = NOW()");

        $product_id = $this->db->getLastId();
        // Add product description
        $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET 
            product_id = '" . (int)$product_id . "', 
            language_id = 1, 
            name = 'Test Product', 
            description = 'This is a test product.', 
            tag = '', 
            meta_title = 'Test Product', 
            meta_description = '', 
            meta_keyword = ''");

        // Link the product to a store
        $this->db->query("INSERT INTO `" . DB_PREFIX . "product_to_store` SET 
            product_id = '" . (int)$product_id . "', store_id = 0");

        // Add product images
        $this->db->query("INSERT INTO `" . DB_PREFIX . "product_image` (product_id, image, sort_order) VALUES 
            ('" . (int)$product_id . "', 'catalog/extension/module/product3dcontrol/images/image_2.jpg', 1),
            ('" . (int)$product_id . "', 'catalog/extension/module/product3dcontrol/images/image_3.jpg', 2)");

        // Insert into oc_product_models table
        $this->db->query("INSERT INTO `" . DB_PREFIX . "product_models` SET 
            product_id = '" . (int)$product_id . "', name = 'test_model'");
        // Get Product ID
        $product_id = $this->db->query("SELECT `product_id` FROM  `" . DB_PREFIX . "product` WHERE `sku` = 'TEST3DPRODUCT' ORDER BY `product_id` DESC")->rows[0]['product_id'];
        // Set 3D Test Model To Product
        $test_model = DIR_IMAGE.'catalog/extension/module/product3dcontrol/products/test/test_model.glb';
        $test_product_dir = DIR_IMAGE.'catalog/extension/module/product3dcontrol/products/'.$product_id;
        if(!is_dir($test_product_dir)){
        	mkdir($test_product_dir);
        }
        file_put_contents($test_product_dir, file_get_contents($test_model));
    }

	public function index() {
		$this->load->language('extension/module/product3dcontrol');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('extension/module/product3dcontrol');

		$this->getList();
	}


	public function edit() {
		$this->load->language('extension/module/product3dcontrol');
		$this->load->model('extension/module/product3dcontrol');
		if(isset($this->request->get['product_id']) AND $this->request->get['product_id'] != ''){
		    $data['product_id'] = $this->request->get['product_id'];
		}else{
		    $this->getList();
		    return false;
		}
		$this->document->setTitle($this->language->get('heading_title'));

		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] , true)
		);

		$data['breadcrumbs'][] = array(
			'text' => 'EDIT PRODUCT 3D VIEW',
			'href' => $this->url->link('extension/module/product3dcontrol/edit', 'user_token=' . $this->session->data['user_token'] , true)
		);
		$data['base'] = $this->getBaseUrl();
        $data['product'] = $this->model_extension_module_product3dcontrol->getProductData($this->request->get['product_id']);
        $data['user_token'] = $this->session->data['user_token'];
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/product3dedit', $data));
	}

	protected function getList() {
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_model'])) {
			$filter_model = $this->request->get['filter_model'];
		} else {
			$filter_model = '';
		}

		if (isset($this->request->get['filter_price'])) {
			$filter_price = $this->request->get['filter_price'];
		} else {
			$filter_price = '';
		}

		if (isset($this->request->get['filter_quantity'])) {
			$filter_quantity = $this->request->get['filter_quantity'];
		} else {
			$filter_quantity = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}

		if (isset($this->request->get['category_id'])) {
			$category_id .= $this->request->get['category_id'];
		}

		if (isset($this->request->get['filter_id'])) {
			$filter_id .= $this->request->get['filter_id'];
		}

		if (isset($this->request->get['filter_category'])) {
			$filter_category .= $this->request->get['filter_category'];
		}

		if (isset($this->request->get['filter_filter'])) {
			$filter_filter .= $this->request->get['filter_filter'];
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'pd.name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = (int)$this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_model'])) {
			$url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_price'])) {
			$url .= '&filter_price=' . $this->request->get['filter_price'];
		}

		if (isset($this->request->get['filter_quantity'])) {
			$url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['products'] = array();

		$filter_data = array(
			'filter_name'	  => $filter_name,
			'filter_model'	  => $filter_model,
			'filter_price'	  => $filter_price,
			'filter_quantity' => $filter_quantity,
			'filter_status'   => $filter_status,
			'category_id'     => $category_id,
            'filter_id'       => $filter_id,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);

		$this->load->model('tool/image');
		$product_total = $this->model_extension_module_product3dcontrol->getTotalProducts($filter_data);

		$results = $this->model_extension_module_product3dcontrol->getProducts($filter_data);

		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $this->model_tool_image->resize($result['image'], 400, 400);
			} else {
				$image = $this->model_tool_image->resize('no_image.png', 400, 400);
			}

			$special = false;

			$product_specials = $this->model_extension_module_product3dcontrol->getProductSpecials($result['product_id']);

			foreach ($product_specials  as $product_special) {
				if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
					$special = $this->currency->format($product_special['price'], $this->config->get('config_currency'));

					break;
				}
			}

			$data['products'][] = array(
				'product_id' => $result['product_id'],
				'image'      => $image,
				'name'       => $result['name'],
				'model'      => $result['model'],
				'price'      => $this->currency->format($result['price'], $this->config->get('config_currency')),
				'special'    => $special,
				'quantity'   => $result['quantity'],
				'status'     => $result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'edit3D'       => $this->url->link('extension/module/product3dcontrol/edit', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $result['product_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_model'])) {
			$url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_price'])) {
			$url .= '&filter_price=' . $this->request->get['filter_price'];
		}

		if (isset($this->request->get['filter_quantity'])) {
			$url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['category_id'])) {
			$url .= '&category_id=' . $this->request->get['category_id'];
		}

		if (isset($this->request->get['filter_id'])) {
			$url .= '&filter_id=' . $this->request->get['filter_id'];
		}

		if (isset($this->request->get['filter_category'])) {
			$url .= '&filter_category=' . $this->request->get['filter_category'];
		}

		if (isset($this->request->get['filter_filter'])) {
			$url .= '&filter_filter=' . $this->request->get['filter_filter'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . '&sort=pd.name' . $url, true);
		$data['sort_model'] = $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . '&sort=p.model' . $url, true);
		$data['sort_price'] = $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . '&sort=p.price' . $url, true);
		$data['sort_quantity'] = $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . '&sort=p.quantity' . $url, true);
		$data['sort_status'] = $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . '&sort=p.status' . $url, true);
		$data['sort_order'] = $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . '&sort=p.sort_order' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_model'])) {
			$url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_price'])) {
			$url .= '&filter_price=' . $this->request->get['filter_price'];
		}

		if (isset($this->request->get['filter_quantity'])) {
			$url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $product_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('extension/module/product3dcontrol', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();
		$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_model'] = $filter_model;
		$data['filter_price'] = $filter_price;
		$data['filter_quantity'] = $filter_quantity;
		$data['filter_status'] = $filter_status;
		
		$data['filter_category'] = $filter_category;
		$data['category_id'] = $category_id;
		$data['filter_filter'] = $filter_filter;
		$data['filter_id'] = $filter_id;


		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/product3dcontrol', $data));
	}

    

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name']) || isset($this->request->get['filter_model'])) {
			$this->load->model('extension/module/product3dcontrol');
			$this->load->model('catalog/option');

			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			if (isset($this->request->get['filter_model'])) {
				$filter_model = $this->request->get['filter_model'];
			} else {
				$filter_model = '';
			}

			if (isset($this->request->get['limit'])) {
				$limit = (int)$this->request->get['limit'];
			} else {
				$limit = 5;
			}

			$filter_data = array(
				'filter_name'  => $filter_name,
				'filter_model' => $filter_model,
				'start'        => 0,
				'limit'        => $limit
			);

			$results = $this->model_extension_module_product3dcontrol->getProducts($filter_data);

			foreach ($results as $result) {
				$option_data = array();

				$product_options = $this->model_extension_module_product3dcontrol->getProductOptions($result['product_id']);

				foreach ($product_options as $product_option) {
					$option_info = $this->model_catalog_option->getOption($product_option['option_id']);

					if ($option_info) {
						$product_option_value_data = array();

						foreach ($product_option['product_option_value'] as $product_option_value) {
							$option_value_info = $this->model_catalog_option->getOptionValue($product_option_value['option_value_id']);

							if ($option_value_info) {
								$product_option_value_data[] = array(
									'product_option_value_id' => $product_option_value['product_option_value_id'],
									'option_value_id'         => $product_option_value['option_value_id'],
									'name'                    => $option_value_info['name'],
									'price'                   => (float)$product_option_value['price'] ? $this->currency->format($product_option_value['price'], $this->config->get('config_currency')) : false,
									'price_prefix'            => $product_option_value['price_prefix']
								);
							}
						}

						$option_data[] = array(
							'product_option_id'    => $product_option['product_option_id'],
							'product_option_value' => $product_option_value_data,
							'option_id'            => $product_option['option_id'],
							'name'                 => $option_info['name'],
							'type'                 => $option_info['type'],
							'value'                => $product_option['value'],
							'required'             => $product_option['required']
						);
					}
				}

				$json[] = array(
					'product_id' => $result['product_id'],
					'name'       => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'model'      => $result['model'],
					'option'     => $option_data,
					'price'      => $result['price']
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function autocompleteCategory() {
		$json = array();

		if (isset($this->request->get['filter_category'])) {
			$this->load->model('extension/module/product3dcontrol');
			
			if (isset($this->request->get['filter_category'])) {
				$filter_category = $this->request->get['filter_category'];
			} else {
				$filter_category = '';
			}

			if (isset($this->request->get['limit'])) {
				$limit = (int)$this->request->get['limit'];
			} else {
				$limit = 5;
			}

			$filter_data = array(
				'filter_category'  => $filter_category,
				'start'        => 0,
				'limit'        => $limit
			);

			$results = $this->model_extension_module_product3dcontrol->getCategoriesByName($filter_data);

			foreach ($results as $result) {

				$json[] = array(
					'category_id' => $result['category_id'],
					'name'       => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function autocompleteFilter() {
		$json = array();
            
		if (isset($this->request->get['filter_filter'])) {
			$this->load->model('extension/module/product3dcontrol');

			if (isset($this->request->get['filter_filter'])) {
				$filter_filter = $this->request->get['filter_filter'];
			} else {
				$filter_filter = '';
			}

			if (isset($this->request->get['limit'])) {
				$limit = (int)$this->request->get['limit'];
			} else {
				$limit = 5;
			}

			$filter_data = array(
				'filter_filter'  => $filter_filter,
				'start'        => 0,
				'limit'        => $limit
			);
			$results = $this->model_extension_module_product3dcontrol->getFiltersByName($filter_data);

			foreach ($results as $result) {

				$json[] = array(
					'filter_id' => $result['filter_id'],
					'name'       => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	private function getBaseUrl() {
	    // Detect protocol
	    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'
	                || $_SERVER['SERVER_PORT'] == 443) ? 'https://' : 'http://';

	    // Hostname (e.g., localhost or example.com)
	    $host = $_SERVER['HTTP_HOST'];

	    // Full path to current script
	    $scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);

	    // Remove everything after the first segment (like /admin/controller)
	    // Assuming index.php is in the root of your site folder (e.g., /my_site/index.php)
	    $parts = explode('/', trim($scriptPath, '/'));

	    // Your base folder (e.g., my_site)
	    $baseFolder = $parts[0];

	    // Return protocol + host + /baseFolder
	    return $protocol . $host . '/' . $baseFolder;
	}

}
